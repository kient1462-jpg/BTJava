package vn.edu.eaut.lab12.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import vn.edu.eaut.lab12.model.Student;

@Service
public class StudentService {

    private final List<Student> students = new ArrayList<>();
    private long nextId = 4;

    public StudentService() {
        students.add(new Student(1L, "SV001", "Nguyen Van An", "an@gmail.com", "DCCNTT14.1"));
        students.add(new Student(2L, "SV002", "Tran Thi Binh", "binh@gmail.com", "DCCNTT14.2"));
        students.add(new Student(3L, "SV003", "Le Van Cuong", "cuong@gmail.com", "DCCNTT14.3"));
    }

    public List<Student> findAll() {
        return new ArrayList<>(students);
    }

    public Optional<Student> findById(Long id) {
        return students.stream()
                .filter(s -> s.getId().equals(id))
                .findFirst();
    }

    public boolean isStudentCodeExists(String code, Long excludeId) {
        if (code == null) {
            return false;
        }

        String value = code.trim();

        return students.stream().anyMatch(s ->
                s.getStudentCode().equalsIgnoreCase(value)
                && (excludeId == null || !s.getId().equals(excludeId))
        );
    }

    public void save(Student student) {
        if (student.getId() == null) {
            student.setId(nextId++);
            students.add(student);
        } else {
            findById(student.getId()).ifPresent(old -> {
                old.setStudentCode(student.getStudentCode());
                old.setFullName(student.getFullName());
                old.setEmail(student.getEmail());
                old.setClassName(student.getClassName());
            });
        }
    }

    public void delete(Long id) {
        students.removeIf(s -> s.getId().equals(id));
    }

    public List<Student> searchByName(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return findAll();
        }

        String key = keyword.trim().toLowerCase();

        return students.stream()
                .filter(s -> s.getFullName().toLowerCase().contains(key))
                .toList();
    }
}
