package vn.edu.eaut.lab12.controller;

import jakarta.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import vn.edu.eaut.lab12.model.Student;
import vn.edu.eaut.lab12.service.StudentService;

@Controller
@RequestMapping("/students")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    // Bài 3: Danh sách sinh viên
    @GetMapping
    public String list(@RequestParam(required = false) String keyword,
                       Model model) {
        if (keyword == null || keyword.isBlank()) {
            model.addAttribute("students", studentService.findAll());
            model.addAttribute("keyword", "");
        } else {
            model.addAttribute("students", studentService.searchByName(keyword));
            model.addAttribute("keyword", keyword);
        }

        return "students/list";
    }

    // Bài 4: Form thêm sinh viên
    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("student", new Student());
        model.addAttribute("pageTitle", "Thêm sinh viên");
        return "students/form";
    }

    // Bài 5 + Bài 10: Validation và mã sinh viên không trùng
    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("student") Student student,
                       BindingResult result,
                       Model model) {

        if (studentService.isStudentCodeExists(
                student.getStudentCode(), student.getId())) {
            result.rejectValue(
                    "studentCode",
                    "duplicate",
                    "Mã sinh viên đã tồn tại"
            );
        }

        if (result.hasErrors()) {
            model.addAttribute(
                    "pageTitle",
                    student.getId() == null ? "Thêm sinh viên" : "Sửa sinh viên"
            );
            return "students/form";
        }

        studentService.save(student);
        return "redirect:/students";
    }

    // Bài 6: Xem chi tiết
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable Long id, Model model) {
        return studentService.findById(id)
                .map(student -> {
                    model.addAttribute("student", student);
                    return "students/detail";
                })
                .orElse("redirect:/students");
    }

    // Bài 7: Sửa
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        return studentService.findById(id)
                .map(student -> {
                    model.addAttribute("student", student);
                    model.addAttribute("pageTitle", "Sửa sinh viên");
                    return "students/form";
                })
                .orElse("redirect:/students");
    }

    // Bài 8: Xóa
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        studentService.delete(id);
        return "redirect:/students";
    }

    // Bài 9: Tìm kiếm sinh viên theo ID
    // Nhập ID -> nếu tìm thấy thì hiển thị trang chi tiết sinh viên
    @GetMapping("/search")
    public String searchById(
            @RequestParam Long id,
            Model model) {

        return studentService.findById(id)
                .map(student -> {
                    model.addAttribute("student", student);
                    return "students/detail";
                })
                .orElse("redirect:/students?error=notfound");
    }
}
