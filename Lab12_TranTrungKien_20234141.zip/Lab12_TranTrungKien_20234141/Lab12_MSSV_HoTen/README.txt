LAB 12 - SPRING MVC STUDENT
Project: lab12-spring-mvc-student
Package: vn.edu.eaut.lab12
Java: 17
Spring Boot + Spring MVC + Thymeleaf + Validation
Du lieu sinh vien luu trong List (khong dung database).

BAI 1: Student model + validation annotations
BAI 2: StudentService va du lieu mau
BAI 3: Hien thi danh sach
BAI 4: Form them sinh vien
BAI 5: @Valid + BindingResult
BAI 6: Xem chi tiet
BAI 7: Sua
BAI 8: Xoa
BAI 9: Tim kiem theo ho ten
BAI 10: Kiem tra ma sinh vien khong trung

CHAY:
1. Mo project bang NetBeans.
2. Clean and Build.
3. Run Lab12Application.java.
4. Mo http://localhost:8080/students

LUU Y:
Project duoc tao theo cau truc Maven Spring Boot Initializr.
Neu NetBeans dang dung JDK 23, hay chon JDK 17 cho project nay.
