/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.baitap;

import java.util.Scanner;

public class BaiTap {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int choice;

        do {

            hienThiMenu();

            System.out.print("Chon bai tap: ");
            choice = scanner.nextInt();

            try {

                switch (choice) {

                    case 1:
                        bai1(scanner);
                        break;

                    case 2:
                        bai2(scanner);
                        break;

                    case 3:
                        bai3(scanner);
                        break;

                    case 4:
                        bai4(scanner);
                        break;

                    case 5:
                        bai5(scanner);
                        break;

                    case 0:
                        System.out.println(
                                "Ket thuc chuong trinh."
                        );
                        break;

                    default:
                        System.out.println(
                                "Lua chon khong hop le!"
                        );
                }

            } catch (IllegalArgumentException ex) {

                System.out.println(
                        "Loi: " + ex.getMessage()
                );
            }

            System.out.println();

        } while (choice != 0);

        scanner.close();
    }

    // ==============================
    // HIỂN THỊ MENU
    // ==============================
    private static void hienThiMenu() {

        System.out.println(
                "=============================================="
        );

        System.out.println(
                "       LAB 1 - CONG NGHE JAVA"
        );

        System.out.println(
                "=============================================="
        );

        System.out.println(
                "1. Tinh tong cac so chan"
        );

        System.out.println(
                "2. Tinh tong nghich dao"
        );

        System.out.println(
                "3. Kiem tra so nguyen to"
        );

        System.out.println(
                "4. Kiem tra va phan loai tam giac"
        );

        System.out.println(
                "5. Hien thi day Fibonacci"
        );

        System.out.println(
                "0. Thoat"
        );

        System.out.println(
                "=============================================="
        );
    }

    // ==============================
    // BÀI 1
    // ==============================
    private static void bai1(Scanner scanner) {

        System.out.print("Nhap n: ");

        int n = scanner.nextInt();

        int ketQua = So.tongChanDenN(n);

        System.out.println(
                "Tong cac so chan = " + ketQua
        );
    }

    // ==============================
    // BÀI 2
    // ==============================
    private static void bai2(Scanner scanner) {

        System.out.print("Nhap n: ");

        int n = scanner.nextInt();

        double ketQua = So.tongNghichDao(n);

        System.out.printf(
                "Tong nghich dao = %.4f%n",
                ketQua
        );
    }

    // ==============================
    // BÀI 3
    // ==============================
    private static void bai3(Scanner scanner) {

        System.out.print("Nhap n: ");

        int n = scanner.nextInt();

        if (So.laSoNguyenTo(n)) {

            System.out.println(
                    n + " la so nguyen to."
            );

        } else {

            System.out.println(
                    n + " khong phai la so nguyen to."
            );
        }
    }

    // ==============================
    // BÀI 4
    // ==============================
    private static void bai4(Scanner scanner) {

        System.out.print("Nhap canh a: ");
        double a = scanner.nextDouble();

        System.out.print("Nhap canh b: ");
        double b = scanner.nextDouble();

        System.out.print("Nhap canh c: ");
        double c = scanner.nextDouble();

        String ketQua = So.loaiTamGiac(a, b, c);

        System.out.println(
                "Ket qua: " + ketQua
        );
    }

    // ==============================
    // BÀI 5
    // ==============================
    private static void bai5(Scanner scanner) {

        System.out.print("Nhap n: ");

        int n = scanner.nextInt();

        String ketQua = So.dayFibonacci(n);

        System.out.println(
                "Day Fibonacci: " + ketQua
        );
    }
}