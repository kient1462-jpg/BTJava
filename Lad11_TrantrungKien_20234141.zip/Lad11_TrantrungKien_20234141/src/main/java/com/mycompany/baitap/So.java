/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.baitap;

public class So {

    // ==============================
    // BÀI 1: TÍNH TỔNG SỐ CHẴN
    // ==============================
    public static int tongChanDenN(int n) {

        kiemTraNguyenDuong(n);

        int s = 0;

        for (int i = 2; i <= n; i += 2) {
            s += i;
        }

        return s;
    }

    // ==============================
    // BÀI 2: TÍNH TỔNG NGHỊCH ĐẢO
    // S = 1 + 1/2 + ... + 1/n
    // ==============================
    public static double tongNghichDao(int n) {

        kiemTraNguyenDuong(n);

        double s = 0;

        for (int i = 1; i <= n; i++) {
            s += 1.0 / i;
        }

        return s;
    }

    // ==============================
    // BÀI 3: KIỂM TRA SỐ NGUYÊN TỐ
    // ==============================
    public static boolean laSoNguyenTo(int n) {

        // Số nhỏ hơn 2 không phải số nguyên tố
        if (n < 2) {
            return false;
        }

        // 2 là số nguyên tố
        if (n == 2) {
            return true;
        }

        // Số chẵn lớn hơn 2 không phải số nguyên tố
        if (n % 2 == 0) {
            return false;
        }

        // Chỉ cần kiểm tra đến căn bậc hai của n
        for (int i = 3; i <= Math.sqrt(n); i += 2) {

            if (n % i == 0) {
                return false;
            }
        }

        return true;
    }

    // ==============================
    // BÀI 4: KIỂM TRA VÀ PHÂN LOẠI
    // TAM GIÁC
    // ==============================
    public static String loaiTamGiac(double a, double b, double c) {

        final double EPS = 1e-9;

        // Kiểm tra cạnh
        if (a <= 0 || b <= 0 || c <= 0) {
            return "Khong phai tam giac";
        }

        // Điều kiện để 3 cạnh tạo thành tam giác
        if (a + b <= c ||
            a + c <= b ||
            b + c <= a) {

            return "Khong phai tam giac";
        }

        // Kiểm tra tam giác đều
        boolean deu =
                Math.abs(a - b) < EPS &&
                Math.abs(b - c) < EPS;

        // Kiểm tra tam giác cân
        boolean can =
                Math.abs(a - b) < EPS ||
                Math.abs(a - c) < EPS ||
                Math.abs(b - c) < EPS;

        // Sắp xếp 3 cạnh tăng dần
        double x = a;
        double y = b;
        double z = c;

        if (x > y) {
            double temp = x;
            x = y;
            y = temp;
        }

        if (y > z) {
            double temp = y;
            y = z;
            z = temp;
        }

        if (x > y) {
            double temp = x;
            x = y;
            y = temp;
        }

        // Kiểm tra tam giác vuông
        boolean vuong =
                Math.abs(x * x + y * y - z * z) < EPS;

        if (deu) {
            return "Tam giac deu";
        }

        if (vuong && can) {
            return "Tam giac vuong can";
        }

        if (vuong) {
            return "Tam giac vuong";
        }

        if (can) {
            return "Tam giac can";
        }

        return "Tam giac thuong";
    }

    // ==============================
    // BÀI 5: FIBONACCI
    // ==============================
    public static String dayFibonacci(int n) {

        kiemTraNguyenDuong(n);

        StringBuilder ketQua = new StringBuilder();

        long a = 0;
        long b = 1;

        for (int i = 1; i <= n; i++) {

            if (i > 1) {
                ketQua.append(" ");
            }

            ketQua.append(a);

            long next = a + b;

            a = b;
            b = next;
        }

        return ketQua.toString();
    }

    // ==============================
    // KIỂM TRA SỐ NGUYÊN DƯƠNG
    // ==============================
    private static void kiemTraNguyenDuong(int n) {

        if (n <= 0) {
            throw new IllegalArgumentException(
                    "n phai la so nguyen duong"
            );
        }
    }
}
